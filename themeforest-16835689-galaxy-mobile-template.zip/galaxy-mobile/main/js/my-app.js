"use strict";
/*===============================================*/
/* INITIALIZE YOUR APP		 			     */
/*===============================================*/
var myApp = new Framework7({
    material: true,
    swipePanel: "left"
});

/*===============================================*/
/* EXPORT SELECTORS ENGINE	 			     */
/*===============================================*/
var $$ = Dom7;
/*===============================================*/
/* ADD VIEW		 			                 */
/*===============================================*/
var mainView = myApp.addView(".view-main", {
    dynamicNavbar: true
});

/*=====================================================*/
/* SHOW/HIDE PRELOADER FOR REMOTE AJAX LOADED PAGES */
/*=====================================================*/
$$(document).on("ajaxStart", function (e) {
    myApp.showIndicator();
});
$$(document).on("ajaxComplete", function () {
    myApp.hideIndicator();
});

$$(document).on("pageInit", function (e) {
/*===============================================*/
/* Swipebox                                   */
/*===============================================*/
    $(".swipebox").swipebox();
/*===============================================*/
/* FIT VIDEOS		 			     */
/*===============================================*/
    $(".videocontainer").fitVids();

    var page = e.detail.page;
    if (page.name === "login") {
        myApp.params.swipePanel = false;
    } else if (page.name === "register") {
        myApp.params.swipePanel = false;
    } else if (page.name === "remember") {
        myApp.params.swipePanel = false;
    } else {
        myApp.params.swipePanel = "left";
    }

    // 
/*===============================================*/
/* ACTION SHEET TO SHARE POSTS		         */
/*===============================================*/
    $(".share-post").on("click", function () {
        var buttons = [
            {text: "<span class=\"text-thiny\">Share this post with your friends</span>", label: true},
            {text: "<span class=\"text-small share-post-icon share-post-facebook\"><i class=\"flaticon-facebook\"></i> Share on Facebook</span>"},
            {text: "<span class=\"text-small share-post-icon share-post-twitter\"><i class=\"flaticon-twitter\"></i> Share on Twitter</span>"},
            {text: "<span class=\"text-small share-post-icon share-post-whatsapp\"><i class=\"flaticon-whatsapp\"></i> Share on Whatsapp</span>"},
            {text: "<span class=\"text-small\">Cancel</span>", color: "red"}
        ];
        myApp.actions(buttons);
    });
});